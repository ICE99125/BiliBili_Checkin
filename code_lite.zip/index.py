from bilibili import BiliBili
from config import config

def main(*args):
    accounts = config.get("multi")

    for item in accounts:
        obj = BiliBili(**item)

        obj.start()

    return True

if __name__ == "__main__":
    main()
