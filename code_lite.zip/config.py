config = {
    "multi": [
        {
            "cookie": "buvid3=1A38841E-C7AE-359F-DE90-5C2AE649329414796infoc; b_nut=1688863214; _uuid=33E9BA9E-FC32-376F-93106-514A4F7919BE22917infoc; buvid_fp=3bed126ebb7a605915b9ffdd43ac7ad2; buvid4=AF422103-B6C3-8238-1D5B-768A8D22AA9F63043-023070908-Koqo8aA/nWTzyZFLIJMO3g%3D%3D; CURRENT_FNVAL=4048; rpdid=|(J|)Jk|muY)0J'uY)))YJkmR; CURRENT_QUALITY=80; FEED_LIVE_VERSION=V8; header_theme_version=CLOSE; home_feed_column=4; b_lsid=6BA7E2CD_18F3C0DCB62; enable_web_push=DISABLE; SESSDATA=24575a64%2C1730251542%2Ca0b18%2A52CjDxwdso3pL4uCXc1H1tV2jDeNQmpunM1qf_PJQNvKUWCoiQdEFfjHYCq2rShHqK70sSVlRvbHRHRlJ4Q1pLY0V2ak9URXBna0w1X2YxWFFaZ2lybzMwejV2bnYxdTFlTHpld1lrWFVxdDhUcFBiSUZEOUt6UUtvd2lwWWE2UGJyX3J6SVg0TDVnIIEC; bili_jct=cb5086db6da548285667cfd011d45dd8; DedeUserID=352635398; DedeUserID__ckMd5=147cae5ffc80d388; sid=80tcgq8u; browser_resolution=764-620",
            "options": {
                "watch": True,  # 每日观看视频
                "coins": 5,  # 投币个数
                "share": True,  # 视频分享
                "comics": True,  # 漫画签到
                "lb": True,  # 直播签到
                "threshold": 1,  # 仅剩多少币时不再投币(不写默认100)
                "toCoin": False,  # 银瓜子兑换硬币
            },
        },
    ],
}
